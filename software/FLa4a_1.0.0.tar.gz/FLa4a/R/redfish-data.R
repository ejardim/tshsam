#' @name rfLen
#' @title redfish length data
#' @description Simulated length data for redfish.  Simulations were done using GADGET.
#' @docType data
#' @usage rfLen
#' @format an \code{FLStock}.
#' @source Daniel Howell
#' @author Ernesto Jardim
NULL

