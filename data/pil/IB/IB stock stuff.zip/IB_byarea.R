# Iberian sardine stock: compare area based to all stock assessment

# NWS stock and index objects are the sum of NW and S stock and index objects
#steps:
# build NWS.stk and NWS.idx
# assess NWS stock: NWS.mcfit (~IB stock)
# assess NW stock: NW.mcfit
# assess S stock: S.mcfit
# sum.fit= NW.mcfit + S.mcfit
# compare NWS.mcfit with sum.fit


library(FLa4a)
library(XML)
library(reshape2)
library(diagram)
library(plot3D)
library(latticeExtra)
library(ggplotFL)

# 
load("C:\\Users\\asilva\\workshops seminars\\a4a workshop\\work\\assessments\\NW\\NW.Rdata")
load("C:\\Users\\asilva\\workshops seminars\\a4a workshop\\work\\assessments\\S\\S.Rdata")
load("C:\\Users\\asilva\\workshops seminars\\a4a workshop\\work\\assessments\\IB\\IB.Rdata")
# 
setwd("C:\\Users\\asilva\\workshops seminars\\a4a workshop\\work\\assessments\\NWS")
# 
NWS.stk<-NW.stk+S.stk
mat(NWS.stk)=mat(NW.stk)
units(harvest(NWS.stk))<-"f"
units(catch.wt(NWS.stk))<-"kg"
units(landings.wt(NWS.stk))<-"kg"
units(stock.wt(NWS.stk))<-"kg"
stock.wt(NWS.stk)<-trim(stock.wt(IB.stk), year=1991:2014)


NWS.idx<-NW.idx
NWS.idx[[1]]<-FLIndex(index=(index(NW.idx[[1]])+index(S.idx[[1]]))/1000,name="ACOUSTIC")
NWS.idx[[2]]<-FLIndexBiomass(index=index(NW.idx[[2]])+index(S.idx[[2]]),name="DEPM")
# 
range(NWS.idx[[1]])[c("startf","endf")]<-c(3/12,5/12) 
range(NWS.idx[[2]])[c("startf","endf")]<-c((1/12),(3/12))
range(NWS.idx[[2]])[c("min","max")]<-c(1,6)
effort(NWS.idx[[1]])[]<-1
effort(NWS.idx[[2]])[]<-1

# to compare IB assessment with sum of NW and S assessment go to ######

###### Do MCMC fits

#NWS.stk<-NWS.stk+fit
fmodel<- ~s(age, k=5)+ te(age,year, k=c(3,12))
qmodel<- list(~s(age,k=4),~1)
NWS.mcfit <- a4aSCA(NWS.stk, NWS.idx,fmodel=fmodel,qmodel=qmodel,fit='MCMC',mcmc=SCAMCMC(mcmc=12500,mcsave=250,mcprobe=0.3))

#NW and S assessments

fmodel<- ~s(age,k=4)+te(age,year,k=c(3,12))
qmodel<- list(~s(age, k=5),~1)

#NW.fit <- sca(NW.stk, NW.idx,fit="assessment",fmodel=fmodel,qmodel=qmodel)
#NW.stk<-NW.stk+NW.fit
NW.mcfit <- a4aSCA(NW.stk, NW.idx,fmodel=fmodel,qmodel=qmodel,fit='MCMC',mcmc=SCAMCMC(mcmc=12500,mcsave=250,mcprobe=0.3))

#S.fit <- sca(S.stk, S.idx,fit="assessment",fmodel=fmodel,qmodel=qmodel)
#S.stk<-S.stk+S.fit
S.mcfit <- a4aSCA(S.stk, S.idx,fmodel=fmodel,qmodel=qmodel,fit='MCMC',mcmc=SCAMCMC(mcmc=12500,mcsave=250,mcprobe=0.3))

#plot fits for NW, S and IB
stks<-FLStocks(IB=NWS.stk+NWS.mcfit,NW=NW.stk+NW.mcfit, S=S.stk+S.mcfit)
plot(stks)

#sum fits for NW and S and compare sum with IB fit

sum.fit<-a4aFitMCMC()
sum.fit@stock.n<-NW.mcfit@stock.n+S.mcfit@stock.n
sum.fit@harvest<-NW.mcfit@harvest+S.mcfit@harvest
sum.fit@catch.n<-NW.mcfit@catch.n+S.mcfit@catch.n

stks<-FLStocks(sum=NWS.stk+sum.fit,IB=NWS.stk+NWS.mcfit)
plot(stks)
